
import math
import re


def parse_order(items_csv):
    if not isinstance(items_csv, str):
        raise ValueError("Order must be a string")

    if not items_csv.strip():
        raise ValueError("Order cannot be empty")

    order = {}

    for item in items_csv.split(','):
        parts = item.split(':')

        if len(parts) != 2:
            raise ValueError("Invalid order format")

        name = parts[0].strip()
        qty_text = parts[1].strip()

        if not name:
            raise ValueError("Item name cannot be empty")

        if not re.fullmatch(r'[0-9]+', qty_text):
            raise ValueError("Quantity must be a positive integer")

        qty = int(qty_text)

        if qty <= 0:
            raise ValueError("Quantity must be greater than zero")

        order[name] = qty

    return order


def delivery_eta(distance_km):
    if isinstance(distance_km, bool):
        raise ValueError("Invalid distance")

    try:
        distance = float(distance_km)
    except (ValueError, TypeError, OverflowError):
        raise ValueError("Distance must be numeric")

    if not math.isfinite(distance) or distance < 0:
        raise ValueError("Distance must be finite and non-negative")

    return int(15 + distance * 4)


def coupon_discount(code):
    if not isinstance(code, str):
        raise ValueError("Coupon must be a string")

    code = code.strip().upper()

    if not re.fullmatch(r'SAVE[0-9]+', code):
        raise ValueError("Invalid coupon code")

    return int(code[4:])


def main():
    print("==== Running parse_order ====")
    user_input = input(
        "Enter items as name:qty CSV (e.g. pizza:2,burger:1): "
    )

    try:
        result = parse_order(user_input)
        print("Order:", result)
    except ValueError as e:
        print("Invalid order:", e)

    print("\n==== Running delivery_eta ====")
    user_input = input("Enter distance in km (e.g. 4.5): ")

    try:
        result = delivery_eta(user_input)
        print("ETA in Minutes:", result)
    except ValueError as e:
        print("Invalid distance:", e)

    print("\n==== Running coupon_discount ====")
    user_input = input("Enter a coupon code (e.g. SAVE50): ")

    try:
        result = coupon_discount(user_input)
        print("Discount:", result)
    except ValueError as e:
        print("Invalid coupon:", e)


if __name__ == "__main__":
    main()
