
from hypothesis import given, strategies as st
from food_delivery import parse_order, delivery_eta, coupon_discount


# TEST 1: ORDER PARSING

@given(st.one_of(st.text(), st.none()))
def test_parse_order_no_crash(s):
    try:
        result = parse_order(s)
        assert isinstance(result, dict)
    except ValueError:
        pass


# TEST 2: DELIVERY ETA

@given(st.one_of(st.text(), st.none()))
def test_delivery_eta_no_crash(s):
    try:
        result = delivery_eta(s)
        assert isinstance(result, int)
        assert result >= 0
    except ValueError:
        pass


# TEST 3: COUPON DISCOUNT

@given(st.one_of(st.text(), st.none()))
def test_coupon_discount_no_crash(s):
    try:
        result = coupon_discount(s)
        assert isinstance(result, int)
        assert result >= 0
    except ValueError:
        pass
