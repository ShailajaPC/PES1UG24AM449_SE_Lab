
import pytest
from food_delivery import (
    delivery_charge,
    apply_coupon,
    estimated_time
)


# DELIVERY CHARGE TESTS

def test_delivery_invalid_low():
    with pytest.raises(ValueError):
        delivery_charge(0, 100, False)


def test_delivery_invalid_high():
    with pytest.raises(ValueError):
        delivery_charge(16, 100, False)


def test_delivery_free_rain():
    assert delivery_charge(5, 500, True) == 30


def test_delivery_near_dry():
    assert delivery_charge(2, 200, False) == 20


def test_delivery_near_rain():
    assert delivery_charge(3, 200, True) == 50


def test_delivery_medium_dry():
    assert delivery_charge(5, 200, False) == 40


def test_delivery_far_dry():
    assert delivery_charge(9, 200, False) == 60


def test_delivery_far_rain():
    assert delivery_charge(9, 200, True) == 90


# COUPON TESTS

def test_coupon_none():
    assert apply_coupon(300, None, False) == 300


def test_coupon_invalid():
    with pytest.raises(ValueError):
        apply_coupon(300, "BAD", False)


def test_welcome_not_first():
    with pytest.raises(ValueError):
        apply_coupon(300, "WELCOME", False)


def test_coupon_small_order():
    assert apply_coupon(150, "SAVE50", False) == 150


def test_welcome_first_large():
    assert apply_coupon(300, "WELCOME", True) == 200


def test_save50_large():
    assert apply_coupon(300, "SAVE50", False) == 250


# ESTIMATED TIME TESTS

def test_eta_no_flags():
    assert estimated_time(2, False, False) == 23


def test_eta_peak_only():
    assert estimated_time(2, True, False) == 33


def test_eta_busy_only():
    assert estimated_time(2, False, True) == 38


def test_eta_peak_and_busy():
    assert estimated_time(2, True, True) == 53
